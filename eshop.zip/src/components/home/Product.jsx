import React from 'react'

const Product = () => {
  return (
    <div className='product_component my-5'>
        <div className="container">
            <h2>Todays Best Deals For You!</h2>
            <div className="row">
              
            </div>
        </div>
    </div>
  )
}

export default Product