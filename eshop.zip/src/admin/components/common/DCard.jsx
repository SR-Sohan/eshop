import React from 'react'

const DCard = () => {
  return (
    <div>DCard</div>
  )
}

export default DCard